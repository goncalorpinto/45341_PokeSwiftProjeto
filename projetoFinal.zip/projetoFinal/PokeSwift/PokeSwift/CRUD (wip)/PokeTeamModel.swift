//
//  PokeTeamModel.swift
//  PokeSwift
//
//  Created by Goncalo Pinto on 05/08/2022.
//

import Foundation
import SwiftUI
import CoreData
