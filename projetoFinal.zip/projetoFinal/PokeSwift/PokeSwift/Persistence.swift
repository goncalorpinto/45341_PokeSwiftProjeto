//
//  Persistence.swift
//  PokeSwift
//
//  Created by Goncalo Pinto on 05/08/2022.
//

import CoreData

struct PersistenceController {
    static let shared = PersistenceController()

}
