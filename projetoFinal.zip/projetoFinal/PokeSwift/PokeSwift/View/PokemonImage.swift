//
//  PokemonImage.swift
//  PokeSwift
//
//  Created by Goncalo Pinto on 03/08/2022.
//

import SwiftUI
import Kingfisher

struct PokemonImage: View {
    var image: KFImage
    
    var body: some View {
        image
            .resizable()
            .scaledToFill()
            .frame(width: 90, height: 90)
            .background(Circle()
                .foregroundColor(.white))
    }
}

struct PokemonImage_Previews: PreviewProvider {
    static var previews: some View {
        PokemonImage(image: KFImage(URL(string: PokemonViewModel().MOCK_POKEMON.imageURL)))
    }
}
