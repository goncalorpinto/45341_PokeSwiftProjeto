//
//  StatsGroup.swift
//  PokeSwift
//
//  Created by Goncalo Pinto on 03/08/2022.
//

import SwiftUI

struct StatsGroup: View {
    var pokemon: Pokemon
    
    var body: some View {
        ZStack{
            Rectangle()
                .frame(width: 300, height: 250)
                .foregroundColor(.white)
                .opacity(0.6)
                .cornerRadius(20)
            
            VStack(alignment: .leading, spacing: 15) {
                StatView(pokemon: pokemon, statName: " HP", statColor: .green, statValue: pokemon.hp)
                StatView(pokemon: pokemon, statName: "ATK", statColor: .red, statValue: pokemon.attack)
                StatView(pokemon: pokemon, statName: "DEF", statColor: .yellow, statValue: pokemon.defense)
                StatView(pokemon: pokemon, statName: "HGT", statColor: .blue, statValue: pokemon.height)
                StatView(pokemon: pokemon, statName: "WGT", statColor: .blue, statValue: pokemon.weight)
            }
        }
    }
}

struct StatsGroup_Previews: PreviewProvider {
    static var previews: some View {
        StatsGroup(pokemon: PokemonViewModel().MOCK_POKEMON)
    }
}
