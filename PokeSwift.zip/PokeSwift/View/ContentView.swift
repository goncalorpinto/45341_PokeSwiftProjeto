//
//  ContentView.swift
//  PokeSwift
//
//  Created by Goncalo Pinto on 02/08/2022.
//

import SwiftUI
import Kingfisher

struct ContentView: View {
    //dados da classe PokemonModel
    @ObservedObject var pokemonVM = PokemonViewModel()
    @State private var searchText = ""
    
    //filtro de pesquisa de pokemons
    var filteredPokemon: [Pokemon] {
        if searchText == "" { return pokemonVM.pokemon }
        return pokemonVM.pokemon.filter {
            $0.name.lowercased().contains(searchText.lowercased())
        }
    }
    
    var body: some View {
        NavigationView {
            List{
                ForEach(filteredPokemon) { poke in
                    NavigationLink(destination: DetailView(pokemon: poke)) {
                        HStack{
                            VStack(alignment: .leading, spacing: 5){
                                Text(poke.name.capitalized)
                                    .font(.title)
                                HStack {
                                    Text(poke.type)
                                        .padding()
                                        .background(poke.typeColor)
                                        .foregroundColor(.white)
                                        .cornerRadius(15)
                                }
                                /*
                                Text(poke.description)
                                    .font(.caption)
                                    .lineLimit(2)
                                 */
                            }
                            
                            Spacer()
                            
                            KFImage(URL(string: poke.imageURL))
                                .interpolation(.none)
                                .resizable()
                                .frame(width: 100, height: 100)
                        }
                    }
                }
            }
            .searchable(text: $searchText, placement: .navigationBarDrawer)
            .navigationTitle("PokeSwift")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
