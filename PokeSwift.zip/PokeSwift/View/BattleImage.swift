//
//  BattleImage.swift
//  PokeSwift
//
//  Created by Goncalo Pinto on 07/08/2022.
//

import SwiftUI
import Kingfisher

struct BattleImage: View {
    var image: KFImage
    
    var body: some View {
        image
            .resizable()
            .scaledToFill()
            .frame(width: 65, height: 65)
            .background(Circle()
                .foregroundColor(.white))
    }
}

struct BattleImage_Previews: PreviewProvider {
    static var previews: some View {
        BattleImage(image: KFImage(URL(string: PokemonViewModel().MOCK_POKEMON.imageURL)))
    }
}
