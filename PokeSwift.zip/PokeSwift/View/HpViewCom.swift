//
//  HpViewCom.swift
//  PokeSwift
//
//  Created by Goncalo Pinto on 07/08/2022.
//

import SwiftUI

import SwiftUI

struct HpViewCom: View {
    var detailview: DetailView
    var statName: String
    var statColor: Color
    var statValue: Int
    
    var body: some View {
        HStack{
            Text("HP")
                .font(.system(.body, design: .monospaced))
            
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: 5)
                    .foregroundColor(.gray)
                    .frame(width: 150, height: 10)
                
                RoundedRectangle(cornerRadius: 5)
                    .foregroundColor(.green)
                    //if statement se statValue <100 trava no 100, ou se <150 trava no 150. se entrar, faz o cálculo do statvalue/100 * 150
                    .frame(width: pokemon.hp <= pokemon.hp ? 100 * (CGFloat(pokemon.hp) / 100) : 150, height: 10)
            }
            Text("\(statValue)")
                .font(.system(.body, design: .monospaced))
        }
        
    }
}

struct HpViewCom_Previews: PreviewProvider {
    static var previews: some View {
        HpViewCom(detailview: PokemonViewModel().MOCK_POKEMON, statName: "HP", statColor: .green, statValue: 55)
    }
}

