//
//  DetailView.swift
//  PokeSwift
//
//  Created by Goncalo Pinto on 03/08/2022.
//

import SwiftUI
import Kingfisher

struct DetailView: View, Identifiable {
    let id = UUID()
    let img = "https://firebasestorage.googleapis.com/v0/b/pokedex-bb36f.appspot.com/o/pokemon_images%2F393CCE37-95EA-4076-8370-6937BEB47FFA?alt=media&token=d376e956-54bc-4811-9670-e288f134ce70"
    let name = "dragonite"
    let type = "flying"
    let hp = Int.random(in: 91...120)
    let attack = 134
    let defense = 95
    var pokemon: Pokemon
    @State private var scale: CGFloat = 0
    
    var body: some View {
        //pokemon
        GeometryReader { geo in
            VStack {
                Text(pokemon.name.capitalized)
                    .font(.largeTitle)
                Text("#000")
                    .foregroundColor(.black)
                    .cornerRadius(15)
                Text(pokemon.type)
                    .padding(10)
                    .background(pokemon.typeColor)
                    .foregroundColor(.white)
                    .cornerRadius(15)
                PokemonImage(image: KFImage(URL(string: pokemon.imageURL)))
                    .zIndex(1)
                ZStack{
                    Rectangle()
                        .edgesIgnoringSafeArea(.all)
                        .frame(width: geo.size.width, height: geo.size.height)
                        .foregroundColor(pokemon.typeColor)
                    VStack {
                        StatsGroup(pokemon: pokemon).padding(-5)
                        Text(pokemon.description.replacingOccurrences(of: "\n", with: ""))
                            .foregroundColor(.white)
                            .padding(50)
                            .font(.title3)
                            
                    }
                }
                .offset(y: -70)
                .scaleEffect(scale)
                .onAppear {
                    let baseAnimation = Animation.spring(dampingFraction: 0.5)
                    let repeated = baseAnimation.repeatCount(1)
                    
                    withAnimation(repeated){
                        scale = 1
                    }
                }
            }
        }.toolbar {
            ToolbarItem(placement: ToolbarItemPlacement.navigationBarTrailing) {
                
                NavigationLink(destination: BattleView(pokemon:pokemon, p1_image: pokemon.imageURL, p1_name: pokemon.name, p1_type: pokemon.type, p1_hp: pokemon.hp, p1_attack: pokemon.attack, p1_defense: pokemon.defense, com_image:img, com_name:name, com_type:type, com_hp:hp, com_attack:attack, com_defense:defense)) {
                    Text("+")
                        .font(.title).bold()
                        .navigationBarTitle("")
                        .navigationBarHidden(false)
                }
            }
        }
    }
}

struct BattleView: View {
    
    var pokemon: Pokemon
    
    @State var p1_image: String
    @State var p1_name: String
    @State var p1_type: String
    @State var p1_hp: Int
    @State var p1_attack: Int
    @State var p1_defense: Int

    @State var com_image: String
    @State var com_name: String
    @State var com_type: String
    @State var com_hp: Int
    @State var com_attack: Int
    @State var com_defense: Int
    
    @State private var showingAlert = false
    
    func ataquePlayer(){
        com_hp = com_hp - p1_attack
    }
    
    func ataqueCOM(){
        p1_hp = p1_hp - p1_attack
    }
    
    func batalha(){
        if com_hp <= 0 {
            com_hp = 0
            showingAlert = true
        }else{
            showingAlert = false
        }
        
        if p1_hp <= 0 {
            p1_hp = 0
            showingAlert = true
        }else{
            showingAlert = false
        }
    }
    
    var body: some View {
        VStack(spacing: 80) {
            HStack {
                VStack(alignment: .trailing){
                    PokemonImage(image: KFImage(URL(string: com_image)))
                        .zIndex(1)
                    NavigationLink(destination: ComDetails(com_image: com_image, com_name: com_name, com_type: com_type, com_hp: com_hp, com_attack: com_attack, com_defense: com_defense)) {
                        Text("\(com_name)")
                    }
                    HpView(pokemon: pokemon, statName: " HP", statColor: .green, statValue: com_hp)
                }
            }
            HStack {
                VStack(alignment: .leading){
                    PokemonImage(image: KFImage(URL(string: p1_image)))
                        .zIndex(1)
                    NavigationLink(destination: PlayerDetails(player_image: p1_image, player_name: p1_name, player_type: p1_type, player_hp: p1_hp, player_attack: p1_attack, player_defense: p1_defense)) {
                        Text("\(p1_name)")
                    }
                    HpView(pokemon: pokemon, statName: " HP", statColor: .green, statValue: p1_hp)
                }
            }
            Button(action: {
                ataquePlayer()
                ataqueCOM()
                batalha()
            }, label: {
                Text("Atacar!")
                    .padding()
                    .foregroundColor(.white)
                    .background(.black)
                    .font(.headline)
            })
            .alert(isPresented: $showingAlert) {
                Alert(title: Text("\(com_name) has fainted!"), message: Text("Volte atrás no botao acima para fazer outra batalha"), dismissButton: .default(Text("Cancelar")))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .font(.title2)
        .navigationBarTitle("")
        .navigationBarBackButtonHidden(false)
        .navigationBarHidden(false)
    }
}

struct PlayerDetails: View {

    @State var player_image: String
    @State var player_name: String
    @State var player_type: String
    @State var player_hp: Int
    @State var player_attack: Int
    @State var player_defense: Int
    
    @Environment(\.presentationMode) var playerDetailsMode: Binding<PresentationMode>
    
    var body: some View {
        VStack {
            PokemonImage(image: KFImage(URL(string: player_image)))
                .zIndex(1)
            Text("Jogador").font(.title2).bold()
            Text("POKEMON: \(player_name)").font(.headline)
            Text("TIPO: \(player_type)").font(.headline)
            Text("HP: \(player_hp)").font(.headline)
            Text("ATK: \(player_attack)").font(.headline)
            Text("DEF: \(player_defense)").font(.headline)
            Button(action: {
                self.playerDetailsMode.wrappedValue.dismiss()
            }) {
                Text("back")
            }
        }
        .navigationBarTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}

struct ComDetails: View {
    
    @State var com_image: String
    @State var com_name: String
    @State var com_type: String
    @State var com_hp: Int
    @State var com_attack: Int
    @State var com_defense: Int
    
    @Environment(\.presentationMode) var comDetailsMode: Binding<PresentationMode>
    
    var body: some View {
        VStack {
            PokemonImage(image: KFImage(URL(string: com_image)))
                .zIndex(1)
            Text("Adversário").font(.title2).bold()
            Text("POKEMON: \(com_name) (COM)").font(.headline)
            Text("TIPO: \(com_type)").font(.headline)
            Text("HP: \(com_hp)").font(.headline)
            Text("ATK: \(com_attack)").font(.headline)
            Text("DEF: \(com_defense)").font(.headline)
            Button(action: {
                self.comDetailsMode.wrappedValue.dismiss()
            }) {
                Text("back")
            }
        }
        .navigationBarTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(pokemon: PokemonViewModel().MOCK_POKEMON)
    }
}
