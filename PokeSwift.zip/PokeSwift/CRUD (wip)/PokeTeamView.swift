//
//  PokeTeamView.swift
//  PokeSwift
//
//  Created by Goncalo Pinto on 05/08/2022.
//

import SwiftUI

struct PokeTeamView: View {
    var body: some View {
        NavigationView {
            List {
                Text("-")
            }
            .toolbar {
                ToolbarItem(placement: ToolbarItemPlacement.navigationBarLeading) {
                    Text("PokeTeam").font(.title2).bold()
                }
                ToolbarItem(placement: ToolbarItemPlacement.navigationBarTrailing) {
                    
                    NavigationLink(destination: ContentView()){
                        Text("+")
                            .font(.title).bold()
                    }
                }
            }
        }
    }
}


struct PokeTeamView_Previews: PreviewProvider {
    static var previews: some View {
        PokeTeamView()
    }
}
