//
//  PokeSwiftApp.swift
//  PokeSwift
//
//  Created by Goncalo Pinto on 02/08/2022.
//

import SwiftUI

@main
struct PokeSwiftApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
